#!/bin/bash
echo "🚀 Starting CRUD App Infrastructure..."
docker-compose up -d
echo "✅ Infrastructure is up and running!"
